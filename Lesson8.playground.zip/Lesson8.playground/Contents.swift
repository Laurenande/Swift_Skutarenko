var dict : [String:String] = ["машина" : "car", "мужчина" : "man"]

var dict3 = [String:String]()
dict["комп"] = "computer"
dict
Array(dict.keys)
Array(dict.values)
//ict["комп"] = "mac"
dict.updateValue("mac", forKey: "комп")
dict.updateValue("mac", forKey: "комп3")

//Task 1
var student = ["Tomas Kol" : 4, "Anna Put" : 4, "Egor Kur" : 3, "Artur Pol" : 2, "Tom Mar" : 3]

//Update
student.updateValue(5, forKey: "Artur Pol")
student["Daria Tor"] = 5

//New student
student["Dana Sin"] = 2

//Stident remove
student.removeValue(forKey: "Tomas Kol")

for (key, value) in student{
    print("Student name = \(key), ball = \(value)")
}

var srBall : Float = 0
var sumBall : Float = 0
for (_, value) in student{
    sumBall += Float(value)
}
srBall = sumBall / Float(student.count)
print("Summa ball = \(sumBall), srBall = \(srBall)")

//Task 2
print("----------------------------------------")
let dayAndMonth = ["Jan":31, "Feb":28, "Mar":31, "Apr":30, "May":31, "Jun":31, "Jul":31, "Aug":30, "Sep":31, "Okt":30,"Nov":31, "Dec":31]
for (key,value) in dayAndMonth{
    print("Month name \(key), day in month \(value)")
}
print("\n")
for key in Array(dayAndMonth.keys){
    print("Month name \(key), day in month \(dayAndMonth[key]!)")
}

//Task 3
let alf = "ABCDEFGH"
let sizeDosk = 8
var doska = [String: Bool]()
for bukva in alf{
    for i in 0..<sizeDosk{
        if (i % 2) > 0{
            let a = "\(bukva)" + "\(i)"
            doska[a] = true
        } else {
            let a = "\(bukva)" + "\(i)"
            doska[a] = false
        }
    }
}
for key in Array(doska.keys){
    print("\(key) - \(doska[key]!)")
}
doska.count
doska["A1"]
doska["A2"]
doska["A3"]
