class StudentClass {
    var name : String
    var age : Int
    
    init() {
        name = "No name"
        age = 20
    }
    init(name: String, age: Int) {
        self.name = name
        self.age = age
    }
}

struct StudentStruct {
    
}
//var student1 = Student(name: "bob", age: 20)

//student1.age

//Homework
//Task 1-5
struct StudentST {
    var name : String
    var lastName : String
    var year : Int
    var srBall : Double
}

var student1 = StudentST(name: "Egor", lastName: "Aurakin", year: 2000, srBall: 4.5)
var student2 = StudentST(name: "Daria", lastName: "Aorms", year: 1999, srBall: 4.6)
var student3 = StudentST(name: "Bob", lastName: "Pol", year: 2001, srBall: 3.3)

var journal1 = [student1, student2, student3]

func printJournal (journal: [StudentST]){
    for i in 0..<journal.count{
        print("№ \(i+1) name \(journal[i].name), lastname \(journal[i].lastName), year \(journal[i].year), ball \(journal[i].srBall)")
    }
}

printJournal(journal: journal1)
print("")
var newJournal = journal1.sorted(by: {$0.srBall > $1.srBall})
printJournal(journal: newJournal)
print("")
var lnJournal = journal1.sorted(by: {$0.lastName == $1.lastName ? $0.name > $1.name : $0.lastName < $1.lastName})
printJournal(journal: lnJournal)
