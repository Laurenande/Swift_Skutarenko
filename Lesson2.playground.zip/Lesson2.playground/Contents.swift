print("Int min = \(Int.min); max = \(Int.max)")
print("Int8 min = \(Int8.min); max = \(Int8.max)")
print("Int16 min = \(Int16.min); max = \(Int16.max)")
print("Int32 min = \(Int32.min); max = \(Int32.max)")
print("Int64 min = \(Int64.min); max = \(Int64.max)")

let a : Int = 5
let b : Float = 5.6
let c : Double = 5.3

let s1 = a + Int(b) + Int(c)
let s2 = Float(a) + b + Float(c)
let s3 = Double(a) + Double(b) + c

if Float(s1)<s2{
    print("s1 < s2")
}
else{
    print("s1 > s2")
}
