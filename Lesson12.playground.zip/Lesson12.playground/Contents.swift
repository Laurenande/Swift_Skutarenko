import Foundation


enum Action {
    case Walk(meters: Int)
    case Run(meters: Int, speed: Int)
    case Stop
    case Turn(direction: Direction)
     
    enum Direction {
        case Left
        case Right
    }
}

var action = Action.Run(meters: 20, speed: 10)

action = .Stop
action = .Walk(meters: 10)
action = .Turn(direction: Action.Direction.Right)

switch action {
case .Stop:
    print("Stop")
case .Walk(let meters) where meters < 40:
    print("walk \(meters)")
case .Turn(let dir) where dir == .Left:
    print("turn left")
case .Turn(let dir) where dir == .Right:
    print("turn right")
default:
    break
}

func spaceTask(){
    print("--------------------")
}
//Task 1
print("------HomeWork------")

enum chessFig {
    enum Color : String {
        case White = "White"
        case Black = "Black"
    }
    enum ChessName : String{
        case King = "King"
        case Queen = "Queen"
        case Bishop = "Bishop"
        case Knight = "Knight"
        case Castle = "Castle"
        case Pawn = "Pawn"
    }
    
    enum World : String {
        case a,b,c,d,e,f,g,h
    }
    case figure(color: Color, name: ChessName, x: World, y: Int)
}


var figure1 : [chessFig] = [.figure(color: .White, name: .King, x: .a, y: 5),
                            .figure(color: .Black, name: .Queen, x: .c, y: 4),
                            .figure(color: .White, name: .Pawn, x: .f, y: 4),
                            .figure(color: .Black, name: .King, x: .f, y: 1),
                            .figure(color: .White, name: .Pawn, x: .e, y: 8)]



//Task 2
func printEnum (enu: chessFig) {
    switch enu {
    case .figure(let col, let ChessName, let xStr, let yInt):
        print("\(col) \(ChessName) x: \(xStr) y: \(yInt)")
    }
}

func printChess (arr: [chessFig]) {
    for i in arr {
        printEnum(enu: i)
    }
}

printChess(arr: figure1)
