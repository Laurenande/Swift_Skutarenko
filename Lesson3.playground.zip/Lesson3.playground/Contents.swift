//Tuples

import os
import Foundation

//let simpleTuple : (Int, String, Bool, Double) = (1, "Hello", true, 3.21)
let simpleTuple = (1, "Hello", true, 3.21)

let (number, greating, check, decimal) = simpleTuple

print(number)
print(greating)
print(check)
print(decimal)

simpleTuple.0
simpleTuple.1
simpleTuple.2
simpleTuple.3

let(_, _, check2, _) = simpleTuple

var tuple = (index: 1, phrase: "Hello", register: true, latency: 2.4)
tuple.index
tuple.phrase
tuple.register
tuple.latency

//change number in tuple
tuple.index = 2
tuple.index

/*
let a = (x:1,y:2)
var b = (x:3,y:4)

b = a
*/

/*
let redColor = "red"
let greenColor = "green"
let blueColor = "blue"
*/
let (redColor, greenColor, blueColor) = ("red","green","blue")
redColor
greenColor
blueColor

let totalNumber = 5
let name = "Alex"
print("\(totalNumber), \(name)")
print((totalNumber,name))
 
//It is Homework code
print("---------------Homework---------------")
var maxForce = (pushUps: 50,pullUp: 20, squats: 30)
var maxForceNas = (pushUps: 37,pullUp: 0, squats: 300)
print("Результаты Егора:")
print("Макс. отжимания = \(maxForce.pushUps) \nМакс. подтягивания = \(maxForce.1) \nМакс. приседания = \(maxForce.squats)\n")

print("Результаты Насти:")
print("Макс. отжимания = \(maxForceNas.pushUps) \nМакс. подтягивания = \(maxForceNas.1) \nМакс. приседания = \(maxForceNas.squats)")
print("--------------------------------------")

var secondTuple = maxForce
maxForce = maxForceNas
maxForceNas = secondTuple
print("Результаты Егора:")
print("Макс. отжимания = \(maxForce.pushUps) \nМакс. подтягивания = \(maxForce.1) \nМакс. приседания = \(maxForce.squats)\n")

print("Результаты Насти:")
print("Макс. отжимания = \(maxForceNas.pushUps) \nМакс. подтягивания = \(maxForceNas.1) \nМакс. приседания = \(maxForceNas.squats)")
print("--------------------------------------")

var difference = (pushUps: maxForce.0 - maxForceNas.0,pullUp: maxForce.1 - maxForceNas.1, squats: maxForce.2 - maxForceNas.2)
print("Разница результатов:")
print("Макс. отжимания = \(difference.pushUps) \nМакс. подтягивания = \(difference.1) \nМакс. приседания = \(difference.squats)")

