var text = "123"
// "123k"

var n = Int(text)

var test = n ?? 0

//Task 1
let dayInMonth = 30
let hoursInDay = 24
let minetsInHour = 60
let secondsInMinets = 60
let myDay = 17
let myMonth = 11
let secondOfMy = ((myMonth * dayInMonth) + myDay) * hoursInDay * minetsInHour * secondsInMinets

print("Секунд с начала года до моего ДР: \(secondOfMy)")
print("--------------------")
//Task 2
let quarter = myMonth / 4
if quarter == 0{
    print("One quarter")
}else if quarter == 1{
    print("Two quarter")
}else if quarter == 2{
    print("Three quarter")
}else if quarter == 3{
    print("4 quarter")
}
print("--------------------")
//Task 3
var a = 1
var b = 3
var c = 5
var d = 9
var e = 4
//a++ больше не работает, надо использовать a +=1
//Task 4
var row = 5
var column = 4
if row % 2 <= 0{
    if column % 2 <= 0{
        print("Черная клетка: \(row), \(column)")
    }else{
        print("Белая клетка: \(row), \(column)")
    }
}else{
    if column % 2 <= 0{
        print("Черная клетка: \(row), \(column)")
    }else{
        print("Белая клетка: \(row), \(column)")
    }
}
print("--------------------")
//Как лучше
let cell = (x: 5, y: 4)
if cell.x % 2 == cell.y % 2{
    print("Black cell")
}else{
    print("White cell")
}


