//Task 1
print("----------------------------------------")
let dayInMonth = [31,28,30,31,31,31,30,30,31,31,31,31]
let nameMonth = ["Январь","Февраль","Март","Апрель","Май","Июнь","Июль","Август","Сентябрь","Октабрь","Ноябрь","Декабрь"]

for day in dayInMonth{
    print(day)
}

print("----------------------------------------")
for (index, value) in dayInMonth.enumerated(){
    print("\(nameMonth[index]) - \(value)")
}
//for i in 0..<dayInMonth.count{
//    print("Mouth name \(nameMonth[i]) day in mouth \(dayInMonth[i])")
//}

print("----------------------------------------")
let dayAndMonth : [(Month:String, Day:Int)] =  [("Январь", 31),("Февраль", 28),("Март", 30),("Апрель", 31),("Май", 31),("Июнь", 31),("Июль", 30),("Август", 30),("Сентябрь", 31),("Октабрь", 31),("Ноябрь", 31),("Декабрь", 31),]

for i in 0..<dayAndMonth.count{
    print("Month name \(dayAndMonth[i].0) day in Month \(dayAndMonth[i].Day)")
}
print("----------------------------------------")
for (month,day) in dayAndMonth.reversed(){
    print("Month name \(month) day in Month \(day)")
}

let day = 23
let month = 2
var sum = 0

for i in 0..<month{
    sum += dayInMonth[i]
}
sum += day
print("Day 23.8 = \(sum)")
//Task 2
/*
let string1 = "3"
let string2 = "34f"
let string3 = "54"
let string4 = "34g"
let string5 = "5"
 let arrayStr = [Int(string1),Int(string2),Int(string3),Int(string4),Int(string5)]
 */
var sumStr = 0
let arrayStr : [Int?] = [1, 2, nil, 45, nil]

for value in arrayStr{
    if value != nil{
        sumStr += value!
    }
}
print("Sum = \(sumStr)")
sumStr = 0

for value in arrayStr{
    if let value = value{
        sumStr += value
    }
}
print("Sum = \(sumStr)")
sumStr = 0

for value in arrayStr{
    sumStr += value ?? 0
}
print("Sum = \(sumStr)")
//Task 3
let alf = "abcdefg"
var arrayAlf = [String]()

for value in alf{
    arrayAlf.insert(String(value), at: 0)
}
print(arrayAlf)
