import Foundation
struct Student {
    var firstName : String {
        willSet{
            print("will set new:" + newValue + " of " + firstName)
        }
        didSet(oldFirstName){
            print("did set new:" + firstName + " of " + oldFirstName)
            firstName = firstName.capitalized
        }
    }
    
    var lastName : String {
        didSet{
            lastName = lastName.capitalized
        }
    }
    
    var fullName : String {
        get{
            return firstName + " " + lastName
        }
        set{
            print("fullName wants to be set to" + newValue )
            
            let words = newValue.components(separatedBy: " ")
            if words.count > 0
            {
                firstName = words[0]
            }
            if words.count > 1
            {
                lastName = words[1]
            }
        }
    }
}
var st = Student(firstName: "Alex", lastName: "loki")

st.firstName
st.lastName
st.fullName

st.firstName = "sam"
st.firstName
st.lastName
st.fullName

st.fullName = "iVAN IVaNoV"
st.firstName
st.lastName
st.fullName
