let number = [4, 3, 7, 9, 3, 66, 33, 44, 56, 31, 21]

func filterArray(array: [Int], f: (Int) -> Bool) -> [Int] {
    var filtered = [Int]()
    for i in array {
        if f(i) {
            filtered.append(i)
        }
    }
    return filtered
}

func compare(i: Int) -> Bool {
    return i % 2 == 0
}

filterArray(array: number, f: compare(i:))
filterArray(array: number, f: {(i: Int) -> Bool in
    return i % 2 == 0
})
filterArray(array: number, f: {(i: Int) -> Bool in
    return i % 2 == 1
})

//MARK: ok
//FIXME: i am
//TODO: fix it

filterArray(array: number, f: {i in
    return i < 10
})
let a =
filterArray(array: number, f: {i in i < 10 })
let a1 =
filterArray(array: number, f: {$0 < 10})
filterArray(array: number) {
    $0 < 10
    
}

let array = [1, 2, 3]
var count = 0
let a4 =
filterArray(array: number) {value in
    for i in array {
        count += 1
        if i == value {
            return true
        }
    }
    return false
}
count
count = 0
var dict = [Int:Bool]()
for value in array {
    dict[value] = true
}

let a5 =
filterArray(array: number) {value in
    count += 1
    return dict[value] != nil
}
count

//Task 1
func spaceTask() {
    print("--------------------")
}
print("------HomeWork------")

func intPrint(f: () -> ()) {
    f()
    for i in 0...10 {
        print("i = \(i)")
    }
    f()
}

intPrint{ return print("Way")}

spaceTask()
//Task 2

var arrayInt = [9, 7, 8, 5, 6, 3, 4, 1, 2 ,6 ]
print(arrayInt.sorted(by: <))
print(arrayInt.sorted(by: >))
spaceTask()
//Task 3

let arrayInt2 = [4,6,7,8,9,22,33,445,67]

func identyInt(array: [Int], f: (Int?,Int) -> (Bool)) -> Int {
    var opt : Int?
    for i in array {
        if f(opt,i) {
            opt = i
        }
    }
    return opt ?? 0
}

print("Min = \(identyInt(array: arrayInt2){$0 == nil || $1 < $0!})")
print("Min = \(identyInt(array: arrayInt2){$0 == nil || $1 > $0!})")

spaceTask()
//Task 4
let textRand = "AsdfgkJiO,*904FGhj,/Uip"

var strChar = [String]()
for value in textRand {
    strChar.append(String(value))
}
func priorety( str: String) -> Int {
    switch str.lowercased() {
    case "a","e","i","o","u","y":
        return 0
    case "a"..."z":
        return 1
    case "0"..."9":
        return 2
    default:
        return 3
    }
}

let resoultArray = strChar.sorted{
    switch (priorety(str: $0),priorety(str: $1)) {
    case let (x, y) where x < y:
        return true
    case let (x, y) where x > y:
        return false
    default:
        return $0 <= $1
    }
}
print(strChar)
print(resoultArray)
spaceTask()
//Task 5
//Проделайте задание №3 но для нахождения минимальной и максимальной буквы из массива букв (соответственно скалярному значению)

func filterdSumbul(array: [String], compare: (Int?,Int) -> (Bool)) -> String? {
    var number : Int?
    var sumbol : String?
    
    for value in array {
        let numberOfValue = Int(UnicodeScalar(String(value))!.value)
        //UnicodeScalar как я понял возвращает числовое значения любого символа 
        //print(numberOfValue)
        if compare(number,numberOfValue) {
            sumbol = value
            number = numberOfValue
        }
    }
    return sumbol
}

if let maxSumbol = filterdSumbul(array: strChar, compare: {$0 == nil || $0! > $1}) {
    print("Max - \(maxSumbol)")
}
if let minSumbol = filterdSumbul(array: strChar, compare: {$0 == nil || $0! < $1}) {
    print("Max - \(minSumbol)")
}
