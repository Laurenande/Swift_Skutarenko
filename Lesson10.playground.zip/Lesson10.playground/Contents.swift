func calculateMoney(inWallet w: [Int], withType type: Int? = nil) -> (total: Int,count: Int){
    var sum = 0
    var count = 0
    for value in w{
        if type == nil || value == type{
            sum += value
            count += 1
        }
    }
    print("Wallet summa = \(sum)")
    return (sum,count)
}

func calculateMoney(inSequence r: Int...) -> Int {
    var sum = 0
    for value in r {
        sum += value
    }
    return sum
}
let wallet = [100,1,5,5,10,20,50,100]

let (money, count) = calculateMoney(inWallet: wallet)
money
count
calculateMoney(inWallet: wallet, withType: 100).count
calculateMoney(inSequence: 4,5,6,7,33,4,5,7,77)


func sayHi() {
    print("Hi")
}
let hi : () -> () = sayHi
//hi()
//hi()


func doSomtinhg(whatToDo: () -> ()){
    whatToDo()
}

doSomtinhg(whatToDo: hi)


func whatToDo() -> () -> (){
    func printHello() {
        print("Hello world")
    }
    return printHello
}

whatToDo()()
let what = whatToDo()
what()

//Task 1
print("------HomeWork------")
func spaceTask(){
    print("--------------------")
}
func heart() -> String {
    return("❤️")
}
func house() -> String {
    return("🏢")
}
func dog() -> String {
    return("🐶")
}
print(heart(),house(),dog())
spaceTask()

//Task 2
func cellInBukv(symbol: String) -> Int {
    let a = "ABCDEFGH"
    var position = 0
    for char in a {
        if String(char) != symbol{
            position += 1
        }
        else {
            break
        }
    }
    return position
}

func whatIsCell(x: String, y: Int) -> String {
    let abc = cellInBukv(symbol: x)
    if abc % 2 == y % 2 {
        return "black"
    } else {
        return "white"
    }
}
let cell = whatIsCell(x: "H", y: 3)
print("Cell H2 is \(cell)")
//Task 3
var array: [Any] = [9,8,7,6,5,4,3,2,1]
var array2: [Any] = ["A","B","C","D","E","F","G","H"]

func reversArray(arrayRevers: [Any]) -> [Any] {
    //return array.reversed() слишком просто
    var a : [Any] = []
    for b in arrayRevers {
        a.insert(b, at: 0)
    }
    return a
}
//Task 4 in 3
func reversArrayInout(arrayReversInout: inout [Any]) {
    //return array.reversed() слишком прост
    for b in arrayReversInout {
        arrayReversInout.insert(b, at: 0)
        arrayReversInout.removeLast()
    }
}
func reversArrayInt(arrayInt: Int...) -> [Any] {
    reversArray(arrayRevers: arrayInt)
}
//let a = reversArray(arrayRevers: array2)
let b = reversArrayInt(arrayInt: 1,2,3,4,5,6,7,8,9)
reversArrayInout(arrayReversInout: &array)
print(array)
print(b)
array
spaceTask()
//Task 5
var text = "akdfjj oj bnjsf iu mnkfsdaf; sdf,f gfd, 9 1 7 7"
func reverseSymbol(t: String) -> String{
    var newText = ""
    let number = ["zero","one", "two","three"]
    for letter in t{
        switch letter {
        case ".", ",", "?", "!":
            newText += " "
        case "a", "o", "i", "e", "u":
            newText += letter.uppercased()
        case "B", "C", "D", "Q", "W", "R", "T", "P", "S":
            newText += letter.lowercased()
        case "0", "1", "2", "3":
            newText += number[Int(String(letter))!]
        case " ":
            newText += " "
        default:
            break
        }
    }
    return newText
}
print(reverseSymbol(t: " 0 1 2 3 anD, CoQ, ASDRE VAer"))
