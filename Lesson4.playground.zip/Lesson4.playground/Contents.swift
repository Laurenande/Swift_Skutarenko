import CoreFoundation
var apples : Int? = 5

apples = nil
if apples == nil{
    print("apples nil")
}else{
    let a = apples! + 2
    print(a)
}

if var number = apples{
    number = number + 2
} else{
    print("apples nil")
}

let age = "60"
if Int(age) != nil{
    let ageNumber = Int(age)
    print(ageNumber as Any)
}

if let ageNumber = Int(age){
    print(ageNumber)
}

var apples2 : Int! = nil

apples2 = 2
apples2 = apples2 + 5

//it is HomeWork
let number1 : String? = "5"
let number2 : String? = "1 r y"
let number3 : String? = "3 er"
let number4 : String? = "11"
let number5 : String? = "4"
var summa : Int?
if summa == nil{
    summa = 0
}

if let a = Int(number1!){
    summa! += a
}

if let a = Int(number2!){
    summa! += a
}

if let a = Int(number3!){
    summa! += a
}

if let a = Int(number4!){
    summa! += a
}

if let a = Int(number5!){
    summa! += a
}

print("----------It is HomeWork----------")
print("Task №1")
print("Value variables:")
print("1: \(number1!)\n2: \(number2!)\n3: \(number3!)\n4: \(number4!)\n5: \(number5!)\n")
print("Summa all variables converting to Int = \(summa!)")
print("\nTask №2")

var serverMassage : (statusCode: Int, errorMassage: String?, massege: String?)
serverMassage.statusCode = 215
serverMassage.errorMassage = "Server is down"
serverMassage.massege = "Server is work"

if serverMassage.statusCode >= 200 && serverMassage.statusCode < 300{
    print(serverMassage.massege!)
}else{
    print(serverMassage.errorMassage!)
}

var serverMassage2 : (errorMassage: String?, massege: String?)

serverMassage2.errorMassage = "Server is down"
if serverMassage2.massege != nil{
    print(serverMassage2.massege!)
}else if serverMassage2.errorMassage != nil{
    print(serverMassage2.errorMassage!)
}
print("\nTask №3")
var student1 : (name: String?, carNumber: String?, testWork: Int?)
var student2 : (name: String?, carNumber: String?, testWork: Int?)
var student3 : (name: String?, carNumber: String?, testWork: Int?)
var student4 : (name: String?, carNumber: String?, testWork: Int?)
var student5 : (name: String?, carNumber: String?, testWork: Int?)
//Name
student1.name = "Egor"
student2.name = "Tom"
student3.name = "Andrey"
student4.name = "Nasta"
student5.name = "Anna"

//Car Number
student1.1 = "AC178K799"
student3.1 = "XY001P56"
student5.1 = "OP786B199"

//Test Work
student1.testWork = 5
student2.testWork = 3
student3.2 = 0
student5.2 = 4


if let checkCar = student1.carNumber{
    if let checkTest = student1.testWork{
        print("Student №1 Name \(student1.0!), car \(checkCar), test work \(checkTest)")
    }else{
        print("Student №1 Name \(student1.0!), car \(checkCar), no test work")
    }
}else{
    if let checkTest = student1.testWork{
        print("Student №1 Name \(student1.0!), no car, test work \(checkTest)")
    }else{
        print("Student №1 Name \(student1.0!), no car, no test work")
    }
}

if let checkCar = student2.carNumber{
    if let checkTest = student2.testWork{
        print("Student №2 Name \(student2.0!), car \(checkCar), test work \(checkTest)")
    }else{
        print("Student №2 Name \(student2.0!), car \(checkCar), no test work")
    }
}else{
    if let checkTest = student2.testWork{
        print("Student №2 Name \(student2.0!), no car, test work \(checkTest)")
    }else{
        print("Student №2 Name \(student2.0!), no car, no test work")
    }
}

print("Student №3 Name \(student2.0!), car \(student3.1), test work \(student3.2)")
print("Student №4 Name \(student4.0!), car \(student4.1), test work \(student4.2)")
print("Student №5 Name \(student5.0!), car \(student5.1), test work \(student5.2)")






