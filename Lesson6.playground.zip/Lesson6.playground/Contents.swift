var str = "🍗"
str.isEmpty
//Task 1
let val1 = "43"
let val2 = "12"
let val3 = "34r"
let val4 = "53ff"
let val5 = "56"

let intFromStr1 = Int(val1) ?? 0
let intFromStr2 = Int(val2) ?? 0
let intFromStr3 = Int(val3) ?? 0
let intFromStr4 = Int(val4) ?? 0
let intFromStr5 = Int(val5) ?? 0

let summ = intFromStr1 + intFromStr2 + intFromStr3 + intFromStr4 + intFromStr5
//интерполяция строки
let str1 = "\(intFromStr1) + \(intFromStr2) + \(intFromStr3) + \(intFromStr4) + \(intFromStr5) = \(summ)"
print(str1)
//конкантенация сторки

let strToInt1 = Int(val1) != nil ? val1 : "nil"
let strToInt2 = Int(val2) != nil ? val2 : "nil"
let strToInt3 = Int(val3) != nil ? val3 : "nil"
let strToInt4 = Int(val4) != nil ? val4 : "nil"
let strToInt5 = Int(val5) != nil ? val5 : "nil"

//let str2 = "\(strToInt1) + \(strToInt2) + \(strToInt3) + \(strToInt4) + \(strToInt5) = \(summ)"
let str2 = strToInt1 + " + " + strToInt2 + " + " + strToInt3 + " + " + strToInt4 + " + " + strToInt5 + " = " + String(summ)
print(str2)
print("--------------------")


//Task 3
let alfavit = "abcdefg"
let poisk : Character = "c"
var index = 0

for g in alfavit{
    if g == poisk{
        print("Index character \(poisk) = \(index)")
    }
    index += 1
}
