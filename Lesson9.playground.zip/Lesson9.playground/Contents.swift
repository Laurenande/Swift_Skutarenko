/*
mainLoop : for _ in 0...1000 {
    for i in 0...20 {
        if i == 10 {
            break mainLoop
        }
        print(i)
    }
}
*/

var age = 67
var name = "Alex"
switch age {
    case 0...16:
        print("школота")
        //fallthrough //переходи в следующий case без проверки условий
    case 17...21:
        print("студент")
    
    default:
    break
            
}

switch name {
    case "Alex" where age < 50:
        print("Hi buudy")
    case "Alex" where age >= 50:
        print("Buy")
    default:
        break
}
var optional : Int? = 5

let tuple = (name, age)
switch tuple {
    case ("Alex", 15):
        print("Hi alex")

    case (_, let number) where number >= 65 && number <= 70:
        print("Hi old men")
    case ("Alex",_):
        print("bo")
    default:
        break
}

let point = (5,-3)
switch point {
    case let (x,y) where x == y:
        print("x==y")
    case let (x,y) where x == -y:
        print("x==-y")
    case let (_,y) where y < 0:
        print("y < 0")
    default:break
}

let array : [Any] = [5, 5.4, Float(5.4)]

switch array[1]{
case let a as Int: print("Int = \(a)")
case let a as Float: print("Float = \(a)")
case _ as Double: print("Double")
default:break
}

print("------HomeWork------")
//Task 1
let text = "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua."
var consonants = 0
var vowels = 0
var symbol = 0
for char in text
{
    switch char {
        case "A", "a","E","e","I","i","O","o","U","u","Y","y":
            consonants += 1
        case "B", "b","C","c","D","d","F","f","G","g","H","h","J","j","K","k","L","l","M","m","N","n","P","p","Q","q","R","r","S","s","T","t","V","v","W","w","X","x","Z","z":
            vowels += 1
        case ".", ","," ":
            symbol += 1
        default:break
    }
}
print("Consonants = \(consonants)")
print("Vowels = \(vowels)")
print("Symbol = \(symbol)")
print("--------------------")
//Task 2

var myAge = 21
switch myAge {
case 0...16:print("Boy")
case 17...40: print("Man")
case 40...110: print("Granddad")
default:break
}
print("--------------------")
//Task 3

let myName = (name:"Егор",surname:"Куракин",patronymic:"Андреевич")

switch myName {
    case let (name1,_,_) where name1.first == "А" || name1.first == "О":
        print("Привет \(name1)")
    case let (name1,_,patronymic1) where patronymic1.first == "В" || patronymic1.first == "Д":
        print("Здравствуйте \(name1) \(patronymic1)")
    case let (_,surname1,_) where surname1.first == "Е" || surname1.first == "З":
        print("Привет \(surname1)")
    default:
        print("Здравствуйте \(myName.surname) \(myName.name) \(myName.patronymic)")
        break
}
print("--------------------")
//Task 4
var pointWar = (6,5)

switch pointWar {
    case let(3...7,y) where y == 5:
        print("Hit")
    //case let (x,y) where (3 < x && x < 7) && y == 5:
      //  print("Hit")
    case let (x,y) where x == 8 && y == 8:
        print("Kill")
    default:
        print("Missed")
}
