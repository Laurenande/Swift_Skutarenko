let name = "Егор"
let lastName = "Куракин"
var age = 21
let study = "Университет"
var curse = 2
let autoCard = "Есть"

print("Информация о студенте:\n Имя: \(name)\n Фамилия: \(lastName)\n Возраст: \(age)\n Образование: \(study)\n Курс: \(curse)\n Водительские права: \(autoCard)")
